import {taskTrace} from '../orchestration/task-trace.js'
import {handoffPrompt} from './context-handoff.js'
import type {HandoffSelection,ContextHandoff} from '../protocol/context-handoff.js'
import {SteeringEventSchema} from "./steering.js"
import {TaskVersionsSchema,type TaskVersions} from '../protocol/file-versions.js'
import {versionInputReceipt,finalizeTaskVersions} from '../artifacts/task-versions.js'
/**
 * 子 agent 执行器（①-B″ · S1）。
 *
 * 三种模式：`single` / `parallel` / `chain`。每个任务**一个独立进程**。
 *
 * ## 进程隔离是不变式 1 的实现，不是实现细节
 *
 * 计划 §6：*"验证者拿不到生产者的上下文，不是因为我们过滤了，
 * 而是因为**它在另一个进程里**。**过滤会漏，进程边界不会。**"*
 *
 * 所以本模块**不提供「同进程跑一个子会话」的选项**。没有那个选项，
 * 就没有人会在赶时间的时候选它。
 *
 * ## 上界从第一天钉死
 *
 * *"没有上界的 fan-out 是一张空白支票。"*（计划 §6）
 *
 * 超过上界时**出声拒绝整批**，而不是截成前 8 个跑。后者是最坏的一种：
 * 用户以为 9 件事都做了。**要么按你说的做，要么说做不了，不做一半。**
 *
 * ## 父子之间说什么：stdout 上的 NDJSON
 *
 * 子进程从 stdin 收一个 JSON 规格，往 stdout 写 NDJSON，最后一行是 `done`：
 *
 * ```
 * {"type":"done","ok":true,"output":"..."}
 * {"type":"done","ok":false,"error":"上下文超了"}
 * ```
 *
 * **退出码 0 但没给出 `done` 也是失败**，不是空结果——那种情况下我们
 * 根本不知道它做了什么，报成「成功且无输出」就是编造。
 */
import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process"
import type { SubagentDefinition } from "./definitions.js"
import { join } from "node:path"
import { 子事件Schema, type SubagentChildSpec, type 子事件 } from "./protocol.js"
import { 按字节截 } from "./clip.js"
import type { ResourceHost } from "./resources.js"
import {taskOutputReservation} from "../bot/output-locks.js"
import {reportExecutionStage} from '../orchestration/execution-context.js'
import {acceptTaskResult,taskInputReceipt,taskPrompt,TaskEvidenceSchema,type TaskSettings,type TaskContract,type TaskReceipt} from "../orchestration/task-contract.js"
import type {RouteToolEvidence} from "../runtime/analysis-route-evidence.js"
import {TaskObservationSchema,type TaskObservation} from '../protocol/task-observation.js'
import type { OrchestrationService } from "../orchestration/service.js"

/** Shared owned-process tree cleanup also used by controlled scientific execution. */
export {killOwnedProcessTree as 杀掉后代} from '../runtime/process-tree.js'
import {killOwnedProcessTree as 杀掉后代} from '../runtime/process-tree.js'

export interface SubagentTask {
  handoff?:HandoffSelection

  contract?: TaskContract
  agent: string
  task: string
}

export type SubagentRequest =
  | { mode: "single"; agent: string; task: string; contract?: TaskContract;handoff?:HandoffSelection }
  | { mode: "parallel"; tasks: SubagentTask[] }
  | { mode: "chain"; chain: SubagentTask[] }

export interface SubagentResult {
  versions?:TaskVersions
  observation?:TaskObservation
  receipt?: TaskReceipt
  evidence?: RouteToolEvidence[]
  agent: string
  /** 实际交给子 agent 的任务文本（chain 模式下 `{previous}` 已经替换过） */
  task: string
  ok: boolean
  output: string
  /** `ok` 为 false 时**必须**有。不带原因的失败等于没报 */
  error?: string
  /** 截断了就要说，且要说清省了多少（规格 7.5） */
  outputTruncated: boolean
  /** 子进程给出的**原始**字节数。界面说「还有 N」要用真数，不是猜 */
  outputBytes: number
}

export interface SubagentRunSummary {
  results: SubagentResult[]
  /** 整批被拒绝的原因（超上界）。**拒绝时 `results` 为空** */
  rejected?: string
  /** chain 模式下停在第几步（1 起）。跑完全程时缺省 */
  stoppedAtStep?: number
}

export type SubagentProgress =
  | { type: "started"; index: number; agent: string; task: string }
  /** 子进程吐的一条过程（2026-09-27）。**到一行转一行**——坞里那一格要在跑的时候就看得见 */
  | { type: "event"; index: number; event: 子事件 }
  | { type: "settled"; index: number; ok: boolean }

/**
 * 上界。**照计划 §6 的数**：8 个任务 / 4 并发。
 *
 * `maxOutputBytes` 计划没给数。取 64 KiB：pi 把模型可见输出压在 50 KB，
 * 同一个量级。**它管的是「回给父模型多少」**，子进程自己的完整输出
 * 不在这里丢——那属于下一片（落盘 + 路径，照 R2 的做法）。
 */
export const SUBAGENT_LIMITS = {
  maxTasks: 8,
  maxConcurrent: 4,
  maxOutputBytes: 64 * 1024,
  /**
   * 单个子 agent 的墙钟上界（审查 debug H7）。**一个子 agent 卡死不该让整批永挂**——
   * 子进程若既不吐结果也不退出（模型端 hang、死循环），没有这个上界那一 lane 就永远
   * 占着，父侧的 `Promise.all` 永远不 resolve。10 分钟：够一次正常子任务跑完，
   * 又不至于让一个哑掉的进程拖住半小时。到点按「中止」同一条路杀干净、报超时。
   */
  maxWallMs: 10 * 60 * 1000,
  /**
   * stdout 上一行的上界（2026-09-27 复审）：过程行到一行转一行，但一个不换行的子进程会让行缓冲无限长。
   * 超过就整行丢掉、记一笔；万一丢的正是 `done` 那一行，失败原因里说清楚。按字符数量，约 4 MB。
   */
  maxLineChars: 4 * 1024 * 1024,
  /** stderr 只留最后这么多字符（2026-09-27 复审）：它只在失败时拿来说原因，刷屏的日志不该攒进内存 */
  stderrTailChars: 16 * 1024,
} as const

export type SubagentLimits = typeof SUBAGENT_LIMITS

/** 起一个子 agent 进程要用的命令。**由调用方决定**，本模块不假设是哪个可执行文件 */
export interface ChildCommand {
  /** Only the installed Pi child entry implements the live stdin control protocol. */
  supportsSteering?:true
  command: string
  args: string[]
  env?: Record<string, string>
}

export type ChildFactory = (spec: {
  definition: SubagentDefinition
  agent: string
  task: string
}) => ChildCommand

/**
 * 子进程规格里**与具体任务无关**的那一半。
 *
 * **做成必填，不留「省略只用于测试」的口子。** 少了它，子进程收到的是半个规格，
 * 而失败方式是「每个子 agent 都说模型不存在」——要跨进程才查得出来。
 */
export interface SubagentContext {
  handoffOf?:(index:number)=>ContextHandoff|undefined

  recordReceipt?:(receipt:TaskReceipt)=>TaskReceipt
  authorize?: (name:string,params:Record<string,unknown>,signal?:AbortSignal)=>string|undefined|Promise<string|undefined>
  provider: string
  /** 默认模型。**定义里写了 `model` 的以定义为准** */
  model: string
  /** 子 agent 的工作目录，与父会话同一个工作区 */
  cwd: string
  modelsPath?: string
  credentials?: Record<string, string>
  /**
   * 每个任务一个 agentDir。**不能共用**——Spike E 实测 pi 会把模型选择
   * 写成 agentDir 级的默认值，共用就会互相串。
   */
  agentDirOf: (index: number) => string
  /** 每个任务/续问一个访问器，目录及作用域不会与并行任务共用。 */
  resources?: (() => ResourceHost) | undefined
}

export interface SubagentExecutorOptions {
  /** A backend policy may disable realtime control without disabling ordinary orchestration. */
  allowSteering?: boolean
  control?: {service:OrchestrationService;addressOf:(index:number)=>string[]}|undefined
  prepareTask?: (index:number,task:SubagentTask,definition:SubagentDefinition)=>TaskSettings|undefined
  orchestration?: { service: OrchestrationService; addressOf: (index: number) => string[] } | undefined
  childOf: ChildFactory
  context: SubagentContext
  limits?: Partial<SubagentLimits>
  /** 每个任务开始 / 结束时回调。界面的 chip 组靠它显示 ⏳ 与 ✓ */
  onProgress?: (p: SubagentProgress) => void
}

/** chain 模式里的占位符 */
const PREVIOUS = "{previous}"

export class SubagentExecutor {
  private readonly control:SubagentExecutorOptions["control"]
  private readonly prepareTask: SubagentExecutorOptions["prepareTask"]
  private readonly orchestration: SubagentExecutorOptions["orchestration"]
  private readonly childOf: ChildFactory
  private readonly context: SubagentContext
  private readonly limits: SubagentLimits
  private readonly onProgress: (p: SubagentProgress) => void

  constructor(opts: SubagentExecutorOptions) {
    this.control=opts.allowSteering===false?undefined:opts.control??opts.orchestration
    this.prepareTask = opts.prepareTask
    this.orchestration = opts.orchestration
    this.childOf = opts.childOf
    this.context = opts.context
    this.limits = { ...SUBAGENT_LIMITS, ...opts.limits }
    this.onProgress = opts.onProgress ?? (() => {})
  }

  async run(
    req: SubagentRequest,
    definitions: readonly SubagentDefinition[],
    signal?: AbortSignal,
  ): Promise<SubagentRunSummary> {
    const tasks = toTasks(req)

    if (tasks.length > this.limits.maxTasks) {
      // **拒绝整批。** 截成前 N 个跑会让用户以为 N+1 件事都做了
      return {
        results: [],
        rejected:
          `一次最多 ${this.limits.maxTasks} 个子 agent 任务，这次给了 ${tasks.length} 个。` +
          `请拆成几批——**没有截断执行，一个都没跑。**`,
      }
    }

    return req.mode === "chain"
      ? this.runChain(tasks, definitions, signal)
      : this.runParallel(tasks, definitions, signal)
  }

  /** parallel 与 single 走同一条路——single 就是只有一个任务的 parallel */
  private async runParallel(
    tasks: SubagentTask[],
    definitions: readonly SubagentDefinition[],
    signal?: AbortSignal,
  ): Promise<SubagentRunSummary> {
    // **结果按输入顺序放回**，不按完成顺序。
    // 「第二个任务的结果」必须永远是 results[1]，否则调用方无从对应
    const results = new Array<SubagentResult>(tasks.length)
    let next = 0

    const worker = async (): Promise<void> => {
      for (;;) {
        const i = next++
        if (i >= tasks.length) return
        results[i] = await this.one(i, tasks[i]!, definitions, signal)
      }
    }

    const lanes = Math.min(this.limits.maxConcurrent, tasks.length)
    await Promise.all(Array.from({ length: lanes }, worker))
    return { results }
  }

  private async runChain(
    steps: SubagentTask[],
    definitions: readonly SubagentDefinition[],
    signal?: AbortSignal,
  ): Promise<SubagentRunSummary> {
    const results: SubagentResult[] = []
    let previous = ""

    for (const [i, step] of steps.entries()) {
      // **第一步也要替换**，替成空串——留着 `{previous}` 字面量传给模型更糟
      const task = step.task.split(PREVIOUS).join(previous)
      const r = await this.one(i, { agent: step.agent, task, ...(step.contract?{contract:step.contract}:{}),...(step.handoff?{handoff:step.handoff}:{}) }, definitions, signal)
      results.push(r)
      if (!r.ok) {
        // **停下。** 拿失败的结果当 `{previous}` 往下传就是编造——
        // 下一步会基于一段并不存在的踏勘结论去做计划
        return { results, stoppedAtStep: i + 1 }
      }
      previous = r.output
    }
    return { results }
  }

  /**
   * 续问（2026-09-27，spec §2.3）：在第 `index` 个子 agent 的记录上再跑一轮。**进程是新的，记忆在会话文件里**——
   * 与团队成员下一轮同一条路（`child.ts` 的 `续接或新建`）。墙钟、整组杀、截断都照 `spawnOne`。
   *
   * 不发 `started` / `settled`：那两条是 chip 与账本的，续问不是主 agent 的行动。
   * 定义被删 / 停用了 → **说清楚，不换人**（与 `one()` 不静默降级同一条）。
   */
  async 续问(
    index: number,
    agent: string,
    text: string,
    definitions: readonly SubagentDefinition[],
    signal?: AbortSignal,
  ): Promise<SubagentResult> {
    const definition = definitions.find((d) => d.name === agent)
    if (!definition) return fail({ agent, task: text }, `没有名为 "${agent}" 的子 agent 了（定义被删了或停用了），续不了`)
    return this.runChild(definition, { agent, task: text }, index, signal, true)
  }

  private async one(
    index: number,
    task: SubagentTask,
    definitions: readonly SubagentDefinition[],
    signal?: AbortSignal,
  ): Promise<SubagentResult> {
    const definition = definitions.find((d) => d.name === task.agent)
    if (!definition) {
      // **不静默降级到某个默认 agent。** 也要说清有哪些可选，
      // 否则用户只能自己去翻目录
      const names = definitions.map((d) => d.name).join(" / ") || "（一个都没有）"
      const result = fail(task, `没有名为 "${task.agent}" 的子 agent。已定义的是：${names}`)
      this.onProgress({ type: "started", index, agent: task.agent, task: task.task })
      this.onProgress({ type: "settled", index, ok: false })
      return result
    }

    this.onProgress({ type: "started", index, agent: task.agent, task: task.task })
    const result = await this.runChild(definition, task, index, signal)
    this.onProgress({ type: "settled", index, ok: result.ok })
    return result
  }

  private async runChild(definition: SubagentDefinition, task: SubagentTask, index: number, signal?: AbortSignal, resume = false): Promise<SubagentResult> {
    let settings:TaskSettings|undefined
    let preparedHandoff:ContextHandoff|undefined
    try {settings=this.prepareTask?.(index,task,definition);preparedHandoff=this.context.handoffOf?.(index)} catch(error){return fail(task,message(error))}
    const execute=async (runSignal:AbortSignal):Promise<SubagentResult>=>{
      const release=settings?await taskOutputReservation(this.context.cwd,settings,runSignal):()=>{}
      try {
        reportExecutionStage('preflight')
        if(runSignal.aborted)return fail(task,"已中止")
        const inputProblem=settings?.contract?taskInputReceipt(settings.contract,this.context.cwd):undefined
        if(inputProblem)return{...fail(task,inputProblem.reason??inputProblem.summary),receipt:inputProblem}
        const versionProblem=await versionInputReceipt(settings,this.context.cwd,runSignal)
        if(versionProblem)return{...fail(task,versionProblem.reason??versionProblem.summary),receipt:versionProblem}
        const handoff=this.context.handoffOf?.(index)
        if(handoff?.sha256!==preparedHandoff?.sha256)throw new Error('排队期间冻结交接快照发生变化；子进程未启动')
        reportExecutionStage('execution')
        const result=await this.spawnOne(definition,task,index,runSignal,resume,settings,handoff)
        if(result.ok&&settings?.contract){
          reportExecutionStage('acceptance')
          const verified=await finalizeTaskVersions(settings,acceptTaskResult(settings.contract,result.output,result.evidence??[],this.context.cwd),this.context.cwd,runSignal,{required:settings.contract.submission==='tool',submitted:result.versions,evidence:result.evidence??[]})
          const receipt=verified.versions&&this.context.recordReceipt?this.context.recordReceipt(verified):verified
          return {...result,receipt,ok:receipt.state==='accepted',...(receipt.state!=='accepted'?{error:receipt.reason??receipt.result?.blockers.join('；')??'任务未通过验收'}:{})}
        }
        return result
      }finally{release()}
    }
    if(!this.orchestration)return execute(signal??new AbortController().signal).catch(error=>fail(task,message(error)))
    const {service,addressOf}=this.orchestration
    if(signal?.aborted||service.isClosed)return fail(task,"父会话已停止，子任务未执行")
    const child=service.register("subagent",addressOf(index),task.agent)
    let result:SubagentResult|undefined
    const outcome=await service.run(child.id,async childSignal=>{
      result=await execute(childSignal)
      return{...(result.evidence?{trace:taskTrace(result.evidence)}:{}),ok:result.ok,output:result.output,...(result.error?{error:result.error}:{}),...(result.receipt?{receipt:result.receipt}:{}),...(result.observation?{observation:result.observation}:{})}
    },signal)
    return result&&result.ok===outcome.ok?result:fail(task,outcome.error??"子任务未执行")
  }

  private spawnOne(
    definition: SubagentDefinition,
    task: SubagentTask,
    index: number,
    signal?: AbortSignal,
    /** 续问（2026-09-27）：续这个运行目录里那份会话，而不是新开一份 */
    续 = false,
    settings?: TaskSettings,
    handoff?:ContextHandoff,
  ): Promise<SubagentResult> {
    const cmd = this.childOf({ definition, agent: task.agent, task: task.task })

    return new Promise<SubagentResult>((resolve) => {
      if (signal?.aborted) return resolve(fail(task, "开始前已被中止"))

      // 显式类型：`onAbort` 在赋值之前就闭包捕获了它，推断不出来
      let child: ChildProcessWithoutNullStreams | undefined
      let resources: ResourceHost | undefined
      try {
        resources = this.context.resources?.()
        child = spawn(cmd.command, cmd.args, {
          stdio: ["pipe", "pipe", "pipe"],
          // 自成进程组(H6):中止/超时时好整组杀,孙进程不成孤儿。Windows 无此语义,不传
          ...(process.platform !== "win32" ? { detached: true } : {}),
          ...(cmd.env ? { env: { ...process.env, ...cmd.env } } : {}),
        })
      } catch (err) {
        // 同步抛出的情形（参数非法等）。**不让它冒泡**——
        // 一个任务起不来不该炸掉整批
        return resolve(fail(task, `子进程起不来：${message(err)}`))
      }

      const control=this.control
      const owner=control?.service.store.list().find(record=>record.kind==='subagent'&&JSON.stringify(record.address)===JSON.stringify(control.addressOf(index)))
      const binding=cmd.supportsSteering&&owner&&owner.state==='running'?{childId:owner.id,epoch:owner.epoch}:undefined
      let detachSteering:(()=>void)|undefined
      let 行缓冲 = ""
      /** 正在丢一行超长的（还没等到它的换行） */
      let 丢弃中 = false
      let 丢了几行 = 0
      let err = ""
      let err省了 = false
      /**
       * **只留最后一条 `done`**（2026-09-27）。过程行到一行转一行，不攒——此前整串攒到 `close` 才解析，
       * 过程行进来之后这个串会长到几 MB，而且在跑的时候一行都看不见。
       * 解析不了的行照旧跳过：那是子进程的噪声（某个库往 stdout 打日志），不该让整个任务失败。
       */
      let 最后done: DoneLine | undefined
      let forced: SubagentResult | undefined
      const 收一行 = (line: string) => {
        if (forced || settled) return
        const s = line.trim()
        if (!s.startsWith("{")) return
        let v: { type?: string; event?: 子事件; id?: string; name?: string; params?: unknown }
        try {
          v = JSON.parse(s) as typeof v
        } catch {
          return
        }
        if(binding&&control&&typeof v.type==='string'&&v.type.startsWith('steer_')){
          try{
            const parsed=SteeringEventSchema.safeParse(v)
            if(!parsed.success)throw new Error('子进程纠偏回执格式无效或超出大小上限')
            const response=parsed.data
            if(response.childId!==binding.childId||response.epoch!==binding.epoch)return
            if(response.type==='steer_ready'&&!detachSteering&&!settings?.contract){
              if(!signal?.aborted&&control.service.store.get(binding.childId)?.epoch===binding.epoch){
                detachSteering=control.service.attachSteering(binding.childId,binding.epoch,receipt=>new Promise<void>((resolve,reject)=>{
                  if(settled||forced||signal?.aborted){reject(new Error('Child stopped'));return}
                  child!.stdin.write(`${JSON.stringify({type:'steer',...binding,id:receipt.id,text:receipt.text})}\n`,error=>error?reject(error):resolve())
                }))
              }
            }else if(response.type==='steer_applied')control.service.applySteering(binding.childId,binding.epoch,response.id)
            else if(response.type==='steer_failed')control.service.failSteering(binding.childId,binding.epoch,response.id,response.error)
          }catch(error){
            // EventEmitter callbacks must never throw on malformed or unpersistable receipts.
            forced??=fail(task,`纠偏回执处理失败：${message(error).slice(0,2048)}`)
            try{control.service.interrupt(binding.childId)}catch{/* drain the owned process even if storage failed */}
            if(child)杀掉后代(child)
          }
          return
        }
        if (v.type === "done") 最后done = v as DoneLine
        else if (v.type === "call" && (resources || this.context.authorize) && typeof v.id === "string" && !settled) {
          const id = v.id
          const reply = (ok: boolean, result: string) => {
            if (settled) return
            try { child?.stdin.write(`${JSON.stringify({type: "reply", id, ok, result})}\n`) } catch { /* 子进程已退出，主失败由 close 报告 */ }
          }
          if(v.name==='task_authorize'&&this.context.authorize&&v.params&&typeof v.params==='object'){
            const request=v.params as {name?:unknown;params?:unknown}
            if(typeof request.name!=='string'||!request.params||typeof request.params!=='object')reply(false,'Invalid authorization request')
            else void Promise.resolve(this.context.authorize(request.name,request.params as Record<string,unknown>,signal)).then(reason=>reply(true,reason??''),error=>reply(false,message(error)))
          }
          else if (v.name !== "resource_search" && v.name !== "resource_read") reply(false, "子任务只允许只读资源方法")
          else if(resources) void resources.call(v.name, v.params).then(result => reply(true, result), error => reply(false, message(error)))
        }
        // 已收尾（中止 / 超时）之后到的过程不再转：chip 已经 settled，再来一行只会让界面以为它还活着
        else if (v.type === "event" && v.event && !settled) {
          const parsed = 子事件Schema.safeParse(v.event)
          if (parsed.success) this.onProgress({ type: "event", index, event: parsed.data })
        }
      }
      let settled = false
      // 墙钟(H7):到点按中止同一条路杀干净、报超时
      const 墙钟 = setTimeout(() => {
        forced ??= fail(task, `子 agent 超过 ${Math.round(this.limits.maxWallMs / 1000)} 秒还没结束，已中止`)
        if (child) 杀掉后代(child)
      }, this.limits.maxWallMs)
      墙钟.unref?.()
      const done = (r: SubagentResult) => {
        if (settled) return
        settled = true
        detachSteering?.()
        clearTimeout(墙钟)
        signal?.removeEventListener("abort", onAbort)
        resolve(r)
      }

      function onAbort() {
        // **真的杀掉它连同后代。** 父侧不看了而已的话，子进程会继续烧钱(H6)
        forced ??= fail(task, "已中止")
        if (child) 杀掉后代(child)
      }
      signal?.addEventListener("abort", onAbort, { once: true })

      child.stdout.setEncoding("utf8")
      child.stderr.setEncoding("utf8")
      /**
       * 按行切（2026-09-27 复审收紧）：**只在新到的这一块里找换行**——在整个缓冲里反复找是平方级的；
       * 一行超过 `maxLineChars` 就整行丢掉（记数，收尾时说），不让一个不换行的子进程把父进程撑爆。
       */
      const 行上限 = this.limits.maxLineChars
      child.stdout.on("data", (d: string) => {
        let 起 = 0
        let i: number
        while ((i = d.indexOf("\n", 起)) >= 0) {
          const 段 = d.slice(起, i)
          if (丢弃中) 丢弃中 = false
          else if (行缓冲.length + 段.length > 行上限) 丢了几行++
          else 收一行(行缓冲 + 段)
          行缓冲 = ""
          起 = i + 1
        }
        if (丢弃中) return
        const 余 = d.slice(起)
        if (行缓冲.length + 余.length > 行上限) {
          丢弃中 = true
          丢了几行++
          行缓冲 = ""
        } else 行缓冲 += 余
      })
      const 尾长 = this.limits.stderrTailChars
      child.stderr.on("data", (d: string) => {
        err += d
        if (err.length > 尾长) {
          err = err.slice(-尾长)
          err省了 = true
        }
      })

      child.on("error", (e) => done(fail(task, `子进程起不来：${e.message}`)))

      child.on("close", (code) => {
        if (forced) return done(forced)
        if (!丢弃中 && 行缓冲.trim()) 收一行(行缓冲)
        行缓冲 = ""
        const report = 最后done

        if (!report) {
          // 两种都在这里落地，措辞不同：非 0 退出有码可报；
          // 0 退出却没结果是**更糟**的一种——我们根本不知道它做了什么
          const detail = err.trim() ? `：${err省了 ? `（stderr 前面省了，只留最后 ${尾长} 字）` : ""}${err.trim()}` : ""
          // 丢过超长行时，结果那一行多半就是被丢的那一行——说出来，别让人以为它什么都没交
          const 丢 = 丢了几行 > 0 ? `（有 ${丢了几行} 行输出超过 ${行上限} 字被丢掉了，结果可能就在其中）` : ""
          return done(
            fail(
              task,
              code === 0
                ? `子进程正常退出，但没有给出结果${丢}${detail}`
                : `子进程以退出码 ${code} 结束${丢}${detail}`,
            ),
          )
        }

        const measured=report.observation===undefined?undefined:TaskObservationSchema.safeParse(report.observation)
        if(measured&&!measured.success)return done(fail(task,'子进程观测格式无效'))
        const observation=measured?.success?{observation:measured.data}:{}
        const versions=report.versions===undefined?undefined:TaskVersionsSchema.safeParse(report.versions)
        if(versions&&!versions.success)return done(fail(task,'子进程内容版本格式无效'))
        if (!report.ok) {
          return done({...fail(task, report.error ?? "子 agent 报告失败，但没有说原因"),...observation})
        }

        if(settings?.contract?.submission==='tool'&&report.submitted!==true)return done({...fail(task,'缺少宿主提交标记，不能用文本完成工具契约'),...observation})
        let evidence:RouteToolEvidence[]|undefined
        if(report.evidence!==undefined){const parsed=TaskEvidenceSchema.safeParse(report.evidence);if(!parsed.success)return done(fail(task,'子进程证据格式无效'));evidence=parsed.data.map(({filesWritten,stepId,execution,...rest})=>({...rest,...(filesWritten?{filesWritten}:{}),...(stepId?{stepId}:{}),...(execution?{execution}:{})}))}
        const full = report.output ?? ""
        const bytes = Buffer.byteLength(full, "utf8")
        const truncated = bytes > this.limits.maxOutputBytes
        done({
          agent: task.agent,
          task: task.task,
          ...(evidence?{evidence}:{}),
          ...observation,...(versions?.success?{versions:versions.data}:{}),
          ok: true,
          // 截断按字节算，但切在字符边界上——按字节切会把 UTF-8 切成半个汉字
          output: truncated ? 按字节截(full, this.limits.maxOutputBytes) : full,
          outputTruncated: truncated,
          outputBytes: bytes,
        })
      })

      /**
       * **stdin 的写入错误要吞掉。**
       *
       * 子进程可能在我们写完之前就退出（起不来、参数不对、立刻 exit），
       * 那时这次写会得到 EPIPE。默认行为是抛一个未处理的 `error` 事件，
       * **整个进程崩掉**——而这条路径上真正的失败已经由 `close` 分支
       * 以更准确的措辞报出来了（退出码 + stderr）。
       *
       * 这不是静默回退：被吞掉的只是「管道对面没人了」这个次生信号，
       * 首要原因照常出声。
       */
      child.stdin.on("error", () => {})

      // 规格从 stdin 递进去，**不走命令行参数**：任务文本可以很长，
      // 而且里面什么字符都可能有
      const ctx = this.context
      const agentDir = ctx.agentDirOf(index)
      const spec: SubagentChildSpec = {
        agent: task.agent,
        ...(binding?{steering:binding}:{}),
        task: taskPrompt(!续&&handoff?handoffPrompt(task.task,handoff):task.task,settings?.contract),
        ...(settings?{taskSettings:settings}:{}),
        ...(ctx.authorize?{authorize:true as const}:{}),
        systemPrompt: definition.systemPrompt,
        provider: ctx.provider,
        // **定义里写了 model 就以定义为准**——子 agent 挑一个便宜模型是常见用法
        model: definition.model ?? ctx.model,
        cwd: ctx.cwd,
        agentDir,
        // 会话落在运行目录里（2026-09-27）：坞里那一格重开后读它、接着问时续它
        transcript: { dir: join(agentDir, "transcript"), resume: 续 },
        ...(definition.tools ? { tools: definition.tools } : {}),
        ...(ctx.modelsPath ? { modelsPath: ctx.modelsPath } : {}),
        ...(ctx.credentials ? { credentials: ctx.credentials } : {}),
        ...(resources ? {resources: true as const} : {}),
      }
      if (resources || ctx.authorize || binding) child.stdin.write(`${JSON.stringify(spec)}\n`)
      else child.stdin.end(JSON.stringify(spec))
    })
  }
}

function toTasks(req: SubagentRequest): SubagentTask[] {
  if (req.mode === "single") return [{ agent: req.agent, task: req.task, ...(req.contract?{contract:req.contract}:{}),...(req.handoff?{handoff:req.handoff}:{}) }]
  return req.mode === "parallel" ? [...req.tasks] : [...req.chain]
}

interface DoneLine {
  versions?:unknown
  submitted?:unknown
  observation?:unknown
  evidence?: unknown
  type: "done"
  ok: boolean
  output?: string
  error?: string
}

function fail(task: SubagentTask, error: string): SubagentResult {
  return {
    agent: task.agent,
    task: task.task,
    ok: false,
    output: "",
    error,
    outputTruncated: false,
    outputBytes: 0,
  }
}

const message = (err: unknown): string => (err instanceof Error ? err.message : String(err))
